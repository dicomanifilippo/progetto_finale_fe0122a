export const environment = {
  production: true,
  baseUrl: 'http://epicode.online/epicodebeservice_v2'
};
